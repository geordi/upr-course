#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <unistd.h>

// If you don't your program runs in external console,
// set "externalConsole" to false to prevent this.
// However, in external console, you should be able to see
// AddressSanitizer output


int main() {
    printf( "Hello, World!\n" );

    return 0;
}
