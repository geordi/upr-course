#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <unistd.h>

int main() {
    printf( "Hello, World!\n" );

    return 0;
}
