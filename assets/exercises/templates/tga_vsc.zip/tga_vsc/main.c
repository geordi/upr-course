#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include "utils.h"


int to_1d( const int row, const int col, const int cols ) {
    return col + row * cols;
}


typedef unsigned char byte;

typedef struct TGAHeader_ TGAHeader;

struct TGAHeader_ {
    byte id_length;
    byte color_map_type;
    byte image_type;
    byte color_map[5];
    byte x_origin[2];
    byte y_origin[2];
    byte width[2];
    byte height[2];
    byte depth;
    byte descriptor;
};

int tgaheader_width( const TGAHeader * header ) {

}

int tgaheader_height( const TGAHeader * header ) {

}

typedef struct TGA_ TGA;

struct TGA_ {
    TGAHeader header;
    byte * data;
};


TGA * tga_new( const int width, const int height, const int init_brightness ) {

    TGA * tga = (TGA *)malloc( sizeof( TGA) );
}

void tga_free( TGA ** self ) {

}

int tga_width( const TGA * self ) {

}

int tga_height( const TGA * self ) {

}

void tga_set_pixel( TGA * self, const int x, const int y, const byte b ) {

}

void tga_write( const TGA * self, const char * filename ) {

}

int main() {
    FILE* file = fopen("carmack.tga", "rb");
    assert(file);

    TGAHeader header = {};
    assert(fread(&header, sizeof(TGAHeader), 1, file) == 1);

    printf("Image type: %d, pixel depth: %d\n", header.image_type, header.depth);

    return 0;
}
