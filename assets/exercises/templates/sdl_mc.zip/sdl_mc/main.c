#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_image.h>
#include <stdbool.h>
#include <assert.h>

#include "sdl_playground.h"

#define WINDOW_WIDTH 800
#define WINDOW_HEIGHT 600


typedef struct {
    SDL_Point pos;
    SDL_Point pos_init;
    SDL_Point vel;
    int score;
} Projectile;


int main()
{
    SDL_Window * window = NULL;
    SDL_Renderer * renderer = NULL;

    bool initialized = sdl_playground_init( &window, &renderer, WINDOW_WIDTH, WINDOW_HEIGHT );

    TTF_Init();

    const int FPS = 60;
    const int frame_delay = 1000 / FPS;
    Uint32 frame_start;
    int frame_time;

    SDL_Event e;
    bool quit = false;
    SDL_Point shield_point = { .x = 0, .y = 0 };
    int shield_time = 0;
    bool bomb_active = true;
    int score = 0;
    char score_text[ 80 ];
    Projectile missile = { .pos.x = 0, .pos.y = 40,
     .pos_init.x = 0, .pos_init.y = 40,
     .vel.x = 1, .vel.y = 1, .score = 15 };

    SDL_Rect score_rect = { .x = WINDOW_WIDTH / 2 - 100 / 2, .y = 50, .w = 100, .h = 20 };
    SDL_Color RGB_WHITE = { 255, 255, 255 };

    TTF_Font * sans = TTF_OpenFont( "Anonymous.ttf", 22 );
    assert( sans );

    SDL_Texture * missile_texture = IMG_LoadTexture( renderer, "atom.svg" );

    while (!quit) {
        frame_start = SDL_GetTicks();

        while (SDL_PollEvent(&e)) {
            if (e.type == SDL_QUIT) {
                quit = true;
            }
            else if ( e.type == SDL_MOUSEBUTTONDOWN ) {
                //printf( "[%d, %d]\n", e.button.x, e.button.y );
                shield_point.x = e.button.x;
                shield_point.y = e.button.y;
                shield_time = 200;
            }
        }

        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255); // Nastavení barvy na černou
        SDL_RenderClear(renderer);                      // Vykreslení pozadí
            
        //int bomb_x1 = pos, bomb_y1 = pos, bomb_x2 = pos + 100, bomb_y2 = pos + 100;

        if ( bomb_active ) {
            SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255); // Nastavení barvy na červenou
            SDL_Rect missile_rect = { .h = 24, .w = 24, .x = missile.pos.x - 12, .y = missile.pos.y - 12 };
            SDL_RenderDrawRect( renderer, &missile_rect );
            SDL_RenderDrawLine( renderer, missile.pos_init.x, missile.pos_init.y, missile.pos.x, missile.pos.y ); // Vykreslení čáry
        }

        // building
        SDL_Rect r = { .x = 500, .y = 500, .w = 50, .h = 75 };
        SDL_SetRenderDrawColor( renderer, 0, 255, 0, 255 );
        SDL_RenderDrawRect( renderer, &r );

        if ( shield_time ) {
            SDL_SetRenderDrawColor( renderer, 255, 0, 255, 255 );
            int shield_w = ( shield_time / 200.0 ) * 80;
            SDL_Rect shield_rect = { .w = shield_w, .h = shield_w, .x = shield_point.x - shield_w / 2, .y = shield_point.y - shield_w / 2 };
            SDL_RenderDrawRect( renderer, &shield_rect );
            SDL_RenderCopy( renderer, missile_texture, NULL, &shield_rect );

            SDL_Rect missile_rect = { .h = 24, .w = 24, .x = missile.pos.x - 12, .y = missile.pos.y - 12 };
            if ( SDL_HasIntersection( &shield_rect, &missile_rect ) ) {
                shield_time = 0;
                bomb_active = false;
                score += missile.score;
            }
        }

        printf( "shield_time= %d\n", shield_time );

        if ( bomb_active ) {
            missile.pos.x += missile.vel.x;
            missile.pos.y += missile.vel.y;
        }

        if ( shield_time > 0 ) {
            shield_time--;
        }

        sprintf( score_text, "Score: %d", score );

        SDL_Surface * score_surface = TTF_RenderText_Solid( sans, score_text, RGB_WHITE );
        SDL_Texture * score_texture = SDL_CreateTextureFromSurface( renderer, score_surface );

        SDL_RenderCopy( renderer, score_texture, NULL, &score_rect );

        SDL_RenderPresent(renderer);  // Prezentace kreslítka

        SDL_DestroyTexture( score_texture );
        SDL_FreeSurface( score_surface );

        frame_time = SDL_GetTicks() - frame_start;
        if ( frame_delay > frame_time ) {
            SDL_Delay( frame_delay - frame_time );
        }
    }

    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();

    return 0;
}