#include <stdio.h>
#include <stdbool.h>

int main()
{
    // every function return's something
    return 0;
}
